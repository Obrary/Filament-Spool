Product: Filament Spool, September 2014

Designer: Ron Thompson

Support:  http://forums.obrary.com/category/designs/filament-spool

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
This spool uses 5mm thick plywood and is designed for CNC routing. All but the last side is glued together as a unit and the last side is held on with screws for easy loading.